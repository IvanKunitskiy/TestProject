package com.demo.actions;

public class LoginActions {

    public void doLogin(String userName, String password) {
    }

    public void doLogOut() {

    }
}

package com.demo;

import com.demo.core.base.BaseTest;
import com.demo.testrail.CustomStepResult;
import com.demo.testrail.TestRailAssert;
import com.demo.testrail.TestRailIssue;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Owner;
import org.testng.annotations.Test;

@Epic("First")
@Feature("First")
@Owner("QA")
public class FirstTest extends BaseTest {

    @TestRailIssue(issueID = 22513)
    @Test(description = "First test")
    public void verifyFirst() {

        logInfo("Step 1: Go to the Log-in page");
        TestRailAssert.assertTrue(false,
                new CustomStepResult("message actual result",
                        "message expected"));

    }
}